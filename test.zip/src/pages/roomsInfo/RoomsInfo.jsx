import React from 'react'
import "./RoomsInfo.css"

function RoomsInfo() {
  return (
    <div>
      <div className="students">
        <table>
          <tr>
            <th>qavat</th>
            <th>xona raqami</th>
            <th>joylar soni</th>
            <th>band joylar</th>
            <th>bo'sh joylar</th>
            <th>jixozlar</th>
            
          </tr>
          <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr> <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr> <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr> <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr> <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr> <tr>
            <td>3</td>
            <td>325</td>
            <td>4</td>
            <td>0</td>
            <td>4</td>
            <td>5</td>
          </tr>
        </table>
      </div>
    </div>
  )
}

export default RoomsInfo