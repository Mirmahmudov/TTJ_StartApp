import React from "react";
import "./StudentInfo.css";

function StudentInfo() {
  return (
    <>
      <div className="students">
        <table>
          <tr>
            <th>№</th>
            <th>FISH</th>
            <th>Jins</th>
            <th>Tel</th>
            <th>kurs</th>
            <th>guruh</th>
            <th>fakultet</th>
            <th>tutor</th>
            <th>manzil</th>
            <th>qarzdor</th>
            <th>xona</th>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek ...</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr> <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek ...</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr> <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek ...</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr> <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek ...</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
        </table>
      </div>
    </>
  );
}

export default StudentInfo;
