import React from "react";
import "./Rooms.css"

function Rooms() {
  return <div>
    
  </div>;
}

export default Rooms;
