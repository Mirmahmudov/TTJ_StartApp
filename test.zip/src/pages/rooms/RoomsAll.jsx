import React from "react";

function RoomsAll() {
  return (
    <div>
      <div className="students">
        <table>
          <tr>
            <th>№</th>
            <th>Qavat</th>
            <th>xona</th>
            <th>joylar soni</th>
            <th>bo'sh joylar</th>
          </tr>
          <tr>
            <td>1</td>
            <td>3 qavat</td>
            <td>322-xona</td>
            <td>5-ta</td>
            <td>2-ta</td>
          </tr>
          <tr>
            <td>1</td>
            <td>3 qavat</td>
            <td>322-xona</td>
            <td>5-ta</td>
            <td>2-ta</td>
          </tr>{" "}
          <tr>
            <td>1</td>
            <td>3 qavat</td>
            <td>322-xona</td>
            <td>5-ta</td>
            <td>2-ta</td>
          </tr>{" "}
          <tr>
            <td>1</td>
            <td>3 qavat</td>
            <td>322-xona</td>
            <td>5-ta</td>
            <td>2-ta</td>
          </tr>{" "}
          <tr>
            <td>1</td>
            <td>3 qavat</td>
            <td>322-xona</td>
            <td>5-ta</td>
            <td>2-ta</td>
          </tr>
        </table>
      </div>
    </div>
  );
}

export default RoomsAll;
