import React from 'react'

function StudentWait() {
  return (
    <div>StudentWait: kutmoqda</div>
  )
}

export default StudentWait