import React from "react";
import "./Students.css";

function StudentAll() {
  return (
    <>
      <div className="students">
        <table>
          <tr >
            <th></th>
            <th>
              <input type="text" placeholder="FISH kiriting" />
            </th>
            <th>
              <select name="" id="">
                <option value="">erkak</option>
                <option value="">Ayol</option>
              </select>
            </th>
            <th>
              <input type="tel" placeholder="Tel raqam kiriting" />
            </th>
            <th>
              <select name="" id="">
                <option value="">1 kurs</option>
                <option value="">2 kurs</option>
                <option value="">3 kurs</option>
                <option value="">4 kurs</option>
              </select>
            </th>
            <th>
              <select name="" id="">
                <option value="">611-21</option>
                <option value="">622-21</option>
                <option value="">613-21</option>
                <option value="">619-21</option>
                <option value="">612-21</option>
              </select>
            </th>
            <th>
              <select name="" id="">
                <option value="">KIF</option>
                <option value="">TK</option>
              </select>
            </th>
            <th>
              <input type="text" placeholder="FISH kiriting" />
            </th>
            <th>
              <select name="" id="">
                <option value="">Namangan</option>
                <option value="">Farg'ona</option>
                <option value="">Qo'qon</option>
              </select>
            </th>
            <th>
              <select name="" id="">
                <option value="">qarzdor</option>
                <option value="">haqdor</option>
              </select>
            </th>
            <th>
              <select name="" id="">
                <option value="">123 xona</option>
                <option value="">352 xona</option>
                <option value="">223 xona</option>
                <option value="">313 xona</option>
                <option value="">213 xona</option>
              </select>
            </th>
          </tr>
          <tr>
            <th>№</th>
            <th>FISH</th>
            <th>Jins</th>
            <th>Tel</th>
            <th>kurs</th>
            <th>guruh</th>
            <th>fakultet</th>
            <th>tutor</th>
            <th>manzil</th>
            <th>qarzdor</th>
            <th>xona</th>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
          <tr>
            <td>0</td>
            <td>Mirmahmudov Asadbek</td>
            <td>erkak</td>
            <td>913444468</td>
            <td>3</td>
            <td>611-21</td>
            <td>KIF</td>
            <td>Kamoliddin Nosirov</td>
            <td>Nam.V Chust.T</td>
            <td>700 000 so'm</td>
            <td>312</td>
          </tr>
        </table>
      </div>
    </>
  );
}

export default StudentAll;
