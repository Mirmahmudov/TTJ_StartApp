import React from "react";
import "./Students.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function Students() {
  return (
    <div>
      <div className="students"></div>
    </div>
  );
}

export default Students;
